export type PlayerStatus = 'active' | 'eliminated';
export type CompetitionStatus = 'active' | 'paused' | 'finished';
export type DailyStatus = 'running' | 'ended' | 'final_pending' | 'final_done';
export type TagStatus = 'pending' | 'confirmed' | 'rejected' | 'undone';

export interface Competition {
  id: string;
  name: string;
  timezone: string;
  start_time: string;
  end_time: string;
  current_day: number;
  status: CompetitionStatus;
  created_at: string;
}

export interface Player {
  id: string;
  name: string;
  status: PlayerStatus;
  eliminated_day: number | null;
  eliminated_at: string | null;
  claimed_device_id: string | null;
  sort_order: number;
  created_at: string;
}

export interface DailyGame {
  id: string;
  competition_id: string;
  day_number: number;
  date: string;
  status: DailyStatus;
  is_final: boolean;
  started_at: string | null;
  ended_at: string | null;
  eliminated_player_id: string | null;
  starting_it_ids: string[];
  final_it_ids: string[];
  created_at: string;
}

export interface ActiveTag {
  id: string;
  daily_game_id: string;
  current_it_player_id: string;
  tag_slot: number;
  started_at: string;
}

export interface Tag {
  id: string;
  daily_game_id: string;
  tag_slot: number;
  tagger_id: string;
  tagged_player_id: string;
  status: TagStatus;
  created_at: string;
  confirmed_at: string | null;
}

export interface Announcement {
  id: string;
  competition_id: string;
  daily_game_id: string | null;
  type: string;
  title: string;
  message: string;
  created_at: string;
}

export interface Schedule {
  startMin: number;
  endMin: number;
  curMin: number;
  localDate: string;
  weekday: string;
  windowActive: boolean;
}

export interface GameSnapshot {
  serverTime: number;
  competition: Competition;
  players: Player[];
  today: DailyGame | null;
  activeTags: ActiveTag[];
  recentTags: Tag[];
  allGames: DailyGame[];
  announcements: Announcement[];
  schedule: Schedule;
}
