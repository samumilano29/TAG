import { ANON_KEY, FUNCTION_URL } from '@/lib/supabase';
import { getDeviceId } from '@/lib/device';
import type { GameSnapshot } from '@/lib/types';

async function call<T = any>(action: string, payload: Record<string, unknown> = {}): Promise<T> {
  const res = await fetch(FUNCTION_URL, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${ANON_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ action, device_id: getDeviceId(), ...payload }),
  });
  const data = await res.json().catch(() => ({ error: 'bad_response' }));
  if (!res.ok || (data && data.error)) {
    const err = new Error(data?.error || `Request failed (${res.status})`);
    (err as any).code = data?.error;
    (err as any).conflict = data?.conflict;
    throw err;
  }
  return data as T;
}

export const api = {
  state: () => call<GameSnapshot>('state'),
  claim: (player_id: string) => call('claim', { player_id }),
  tag: (tagger_id: string, tagged_player_id: string) => call('tag', { tagger_id, tagged_player_id }),
  confirmTag: (tag_id: string, player_id: string) => call('confirm_tag', { tag_id, player_id }),
  rejectTag: (tag_id: string, player_id: string) => call('reject_tag', { tag_id, player_id }),
  admin: (adminAction: string, pin: string, payload: Record<string, unknown> = {}) =>
    call(`admin_${adminAction}`, { pin, ...payload }),
};
