import { useCallback, useEffect, useMemo, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { api } from '@/lib/api';
import { getDeviceId, getSavedPlayerId, savePlayerId } from '@/lib/device';
import { useGame } from '@/hooks/useGame';
import { useServerClock } from '@/lib/time';
import type { Player } from '@/lib/types';
import { pendingTagForMe, playerById } from '@/lib/selectors';
import { PlayerSelect } from '@/components/PlayerSelect';
import { Home } from '@/components/Home';
import { Days } from '@/components/Days';
import { Announcements } from '@/components/Announcements';
import { Rules } from '@/components/Rules';
import { Settings } from '@/components/Settings';
import { Admin } from '@/components/Admin';
import { BottomNav, type Tab } from '@/components/BottomNav';
import { TagModal } from '@/components/TagModal';
import { ConfirmTagBanner } from '@/components/ConfirmTagBanner';
import { EndOfDayOverlay } from '@/components/EndOfDayOverlay';
import { useNotifications } from '@/hooks/useNotifications';
import { NotificationStack } from '@/components/NotificationStack';

function App() {
  const { snapshot, loading, error, refresh } = useGame();
  const serverNow = useServerClock(snapshot);

  const [myId, setMyId] = useState<string | null>(() => getSavedPlayerId());
  const [tab, setTab] = useState<Tab>('home');
  const [showTagModal, setShowTagModal] = useState(false);
  const [showAdmin, setShowAdmin] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);

  const me: Player | undefined = useMemo(
    () => (snapshot && myId ? playerById(snapshot, myId) : undefined),
    [snapshot, myId],
  );

  const { notifications, dismiss } = useNotifications(snapshot, me);

  const claim = useCallback(
    async (player: Player) => {
      await api.claim(player.id);
      savePlayerId(player.id);
      setMyId(player.id);
      refresh();
    },
    [refresh],
  );

  const handleTag = useCallback(
    async (targetId: string) => {
      if (!me) return;
      await api.tag(me.id, targetId);
      refresh();
    },
    [me, refresh],
  );

  const confirmTag = useCallback(
    async (tagId: string) => {
      if (!me) return;
      await api.confirmTag(tagId, me.id);
      refresh();
    },
    [me, refresh],
  );

  const rejectTag = useCallback(
    async (tagId: string) => {
      if (!me) return;
      await api.rejectTag(tagId, me.id);
      refresh();
    },
    [me, refresh],
  );

  // Show a pending tag banner if I'm being tagged.
  const pendingForMe = snapshot && me ? pendingTagForMe(snapshot, me.id) : undefined;

  if (loading) {
    return (
      <div className="app-bg flex min-h-screen items-center justify-center">
        <div className="text-center">
          <Loader2 className="mx-auto h-10 w-10 animate-spin text-blue-400" />
          <p className="mt-4 font-display text-2xl font-black text-white">TAG!</p>
          <p className="mt-1 text-sm text-ink-500">Loading the game…</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="app-bg flex min-h-screen items-center justify-center px-5">
        <div className="max-w-sm text-center">
          <p className="font-display text-3xl font-black text-white">Connection issue</p>
          <p className="mt-2 text-sm text-ink-400">{error}</p>
          <button
            onClick={refresh}
            className="mt-5 rounded-xl bg-blue-500 px-6 py-3 font-bold text-white active:scale-95"
          >
            Try again
          </button>
        </div>
      </div>
    );
  }

  if (!snapshot) return null;

  // No identity chosen yet → player selection.
  if (!me) {
    return (
      <>
        <PlayerSelect
          players={snapshot.players}
          onClaim={claim}
          onAdminLogin={() => setShowAdmin(true)}
        />
        {showAdmin && <Admin snapshot={snapshot} onClose={() => setShowAdmin(false)} onDone={refresh} />}
      </>
    );
  }

  const pendingTag = pendingForMe;

  return (
    <div className="app-bg min-h-screen">
      {tab === 'home' && (
        <Home snapshot={snapshot} me={me} serverNow={serverNow} onOpenTag={() => setShowTagModal(true)} />
      )}
      {tab === 'days' && <Days snapshot={snapshot} />}
      {tab === 'announcements' && <Announcements snapshot={snapshot} />}
      {tab === 'rules' && <Rules />}
      {tab === 'settings' && (
        <Settings
          snapshot={snapshot}
          me={me}
          onSwitchPlayer={() => {
            setMyId(null);
            setTab('home');
          }}
          onOpenAdmin={() => setShowAdmin(true)}
        />
      )}

      <BottomNav tab={tab} onChange={setTab} />

      {showTagModal && (
        <TagModal
          snapshot={snapshot}
          me={me}
          onClose={() => setShowTagModal(false)}
          onTag={handleTag}
        />
      )}

      {pendingTag && (
        <ConfirmTagBanner
          snapshot={snapshot}
          tag={pendingTag}
          me={me}
          onConfirm={confirmTag}
          onReject={rejectTag}
        />
      )}

      <EndOfDayOverlay snapshot={snapshot} onDismiss={refresh} />

      <NotificationStack notifications={notifications} onDismiss={dismiss} />

      {showAdmin && <Admin snapshot={snapshot} onClose={() => setShowAdmin(false)} onDone={refresh} />}

      {actionError && (
        <div className="fixed bottom-20 left-1/2 z-50 -translate-x-1/2 rounded-xl bg-it-deep px-4 py-2 text-sm text-white">
          {actionError}
        </div>
      )}
    </div>
  );
}

export default App;
