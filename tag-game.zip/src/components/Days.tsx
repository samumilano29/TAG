import { Calendar, Skull, ArrowRight } from 'lucide-react';
import type { GameSnapshot, Player } from '@/lib/types';
import { playerById } from '@/lib/selectors';

interface Props {
  snapshot: GameSnapshot;
}

export function Days({ snapshot }: Props) {
  const games = [...snapshot.allGames].sort((a, b) => b.day_number - a.day_number);

  if (games.length === 0) {
    return (
      <div className="mx-auto max-w-md px-4 pt-20 text-center text-ink-500">
        <Calendar className="mx-auto h-10 w-10 text-ink-600" />
        <p className="mt-4 font-display text-2xl font-black text-white">No days yet</p>
        <p className="mt-1 text-sm">The first day begins at 7:20 AM.</p>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-md space-y-4 px-4 pb-28 pt-5">
      <h1 className="font-display text-4xl font-black text-white">DAYS</h1>
      {games.map((g) => {
        const starting = g.starting_it_ids.map((id) => playerById(snapshot, id)).filter(Boolean) as Player[];
        const final = g.final_it_ids.map((id) => playerById(snapshot, id)).filter(Boolean) as Player[];
        const eliminated = playerById(snapshot, g.eliminated_player_id);
        const isFinal = g.is_final;
        return (
          <div key={g.id} className="rounded-2xl border border-ink-700 bg-ink-800 p-5">
            <div className="flex items-center justify-between">
              <p className="font-display text-2xl font-black text-white">
                {isFinal ? 'FINAL DAY' : `DAY ${g.day_number}`}
              </p>
              <span
                className={`rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider ${
                  g.status === 'running'
                    ? 'bg-safe/20 text-safe-bright'
                    : g.status === 'final_pending'
                      ? 'bg-pending/20 text-pending-bright'
                      : 'bg-ink-700 text-ink-400'
                }`}
              >
                {g.status === 'running' ? 'Live' : g.status === 'final_pending' ? 'Pending' : 'Ended'}
              </span>
            </div>

            {starting.length > 0 && (
              <div className="mt-4">
                <p className="text-xs font-semibold uppercase tracking-wider text-ink-500">Starting IT</p>
                <div className="mt-1 flex flex-wrap gap-2">
                  {starting.map((p) => (
                    <span key={p.id} className="rounded-lg bg-it-deep/30 px-3 py-1 text-sm font-semibold text-it-bright">
                      {p.name}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {final.length > 0 && (
              <div className="mt-3">
                <p className="text-xs font-semibold uppercase tracking-wider text-ink-500">Final IT</p>
                <div className="mt-1 flex flex-wrap gap-2">
                  {final.map((p) => (
                    <span key={p.id} className="rounded-lg bg-it-deep/30 px-3 py-1 text-sm font-semibold text-it-bright">
                      {p.name}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {eliminated && (
              <div className="mt-3 flex items-center gap-2 rounded-xl border border-ink-600 bg-ink-900/60 px-3 py-2.5">
                <Skull className="h-4 w-4 text-ink-400" />
                <p className="text-sm font-semibold text-ink-300">
                  <span className="text-white">{eliminated.name}</span> eliminated
                </p>
              </div>
            )}

            {isFinal && g.status === 'final_pending' && (
              <p className="mt-3 rounded-xl bg-pending/15 px-3 py-2 text-sm text-pending-bright">
                Final day — awaiting admin decision.
              </p>
            )}
          </div>
        );
      })}
    </div>
  );
}
