import { useState } from 'react';
import { Skull, X, Check, Lock } from 'lucide-react';
import type { Player } from '@/lib/types';
import { api } from '@/lib/api';

interface Props {
  players: Player[];
  onClaim: (player: Player) => Promise<void>;
  onAdminLogin: (pin: string) => void;
}

export function PlayerSelect({ players, onClaim, onAdminLogin }: Props) {
  const [selected, setSelected] = useState<Player | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const confirm = async () => {
    if (!selected) return;
    setBusy(true);
    setError(null);
    try {
      await onClaim(selected);
    } catch (e) {
      const code = (e as any)?.code;
      setError(
        code === 'already_claimed'
          ? 'Someone is already using this name on another device. Ask the admin to reset it.'
          : 'Could not select this player. Try again.',
      );
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="app-bg min-h-screen px-5 pt-12 pb-10">
      <div className="mx-auto max-w-md">
        <p className="text-center text-xs font-semibold uppercase tracking-[0.35em] text-blue-400">TAG!</p>
        <h1 className="mt-3 text-center font-display text-5xl font-black text-white">WHO ARE YOU?</h1>
        <p className="mt-3 text-center text-sm text-ink-500">Tap your name to join the game.</p>

        <div className="mt-8 grid grid-cols-2 gap-3">
          {players.map((p) => {
            const eliminated = p.status === 'eliminated';
            return (
              <button
                key={p.id}
                onClick={() => !eliminated && setSelected(p)}
                disabled={eliminated}
                className={`relative flex h-24 items-center justify-center rounded-2xl border px-3 text-center font-display text-xl font-black transition active:scale-95 ${
                  eliminated
                    ? 'cursor-not-allowed border-ink-700 bg-ink-800/50 text-ink-600'
                    : 'border-ink-700 bg-ink-800 text-white hover:border-blue-500 hover:bg-ink-700'
                }`}
              >
                {eliminated && <Skull className="absolute right-2 top-2 h-4 w-4 text-ink-600" />}
                {p.name}
              </button>
            );
          })}
        </div>

        <div className="mt-8 flex justify-center">
          <AdminLogin onAdminLogin={onAdminLogin} />
        </div>
      </div>

      {selected && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 p-4 sm:items-center">
          <div className="w-full max-w-sm animate-slide-down rounded-3xl border border-ink-700 bg-ink-900 p-6 text-center">
            <h2 className="font-display text-3xl font-black text-white">
              ARE YOU {selected.name.toUpperCase()}?
            </h2>
            <p className="mt-2 text-sm text-ink-500">Your choice is saved on this device.</p>
            {error && <p className="mt-4 rounded-xl bg-it-deep/30 px-3 py-2 text-sm text-it-bright">{error}</p>}
            <div className="mt-6 flex gap-3">
              <button
                onClick={() => {
                  setSelected(null);
                  setError(null);
                }}
                disabled={busy}
                className="flex flex-1 items-center justify-center gap-2 rounded-xl border border-ink-600 py-3 font-semibold text-ink-200 transition active:scale-95"
              >
                <X className="h-4 w-4" /> Cancel
              </button>
              <button
                onClick={confirm}
                disabled={busy}
                className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-safe py-3 font-semibold text-white transition active:scale-95 disabled:opacity-60"
              >
                <Check className="h-4 w-4" /> {busy ? 'Saving…' : "Yes, that's me"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function AdminLogin({ onAdminLogin }: { onAdminLogin: (pin: string) => void }) {
  const [open, setOpen] = useState(false);
  const [pin, setPin] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (!pin) return;
    setBusy(true);
    setError(null);
    try {
      // Any admin action validates the pin; start_day failing with "already_running" still means pin is valid.
      await api.admin('start_day', pin);
      onAdminLogin(pin);
    } catch (e: any) {
      if (e?.message === 'already_running' || e?.message === 'unauthorized') {
        // "already_running" means pin was accepted but day already started — pin is valid.
        // "unauthorized" means wrong pin.
        if (e?.message === 'already_running') {
          onAdminLogin(pin);
          return;
        }
        setError('Wrong pin. Try again.');
      } else {
        // Other errors (not_enough_players, etc.) also mean pin was accepted.
        onAdminLogin(pin);
      }
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="flex items-center gap-2 text-sm font-semibold text-ink-500 transition hover:text-ink-300 active:scale-95"
      >
        <Lock className="h-4 w-4" /> Admin login
      </button>

      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-5">
          <div className="w-full max-w-sm animate-scale-in rounded-3xl border border-ink-700 bg-ink-900 p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Lock className="h-5 w-5 text-ink-300" />
                <h2 className="font-display text-2xl font-black text-white">Admin</h2>
              </div>
              <button onClick={() => { setOpen(false); setPin(''); setError(null); }} className="rounded-full bg-ink-800 p-2 text-ink-400 active:scale-90">
                <X className="h-5 w-5" />
              </button>
            </div>
            <p className="mt-4 text-sm text-ink-400">Enter the admin pin to manage the game.</p>
            <input
              type="password"
              value={pin}
              onChange={(e) => setPin(e.target.value)}
              placeholder="Pin"
              className="mt-4 w-full rounded-xl border border-ink-600 bg-ink-800 px-4 py-3 text-white outline-none focus:border-blue-500"
            />
            {error && <p className="mt-3 text-sm text-it-bright">{error}</p>}
            <button
              onClick={submit}
              disabled={!pin || busy}
              className="mt-4 w-full rounded-xl bg-blue-500 py-3 font-bold text-white active:scale-95 disabled:opacity-50"
            >
              {busy ? 'Checking…' : 'Unlock'}
            </button>
          </div>
        </div>
      )}
    </>
  );
}
