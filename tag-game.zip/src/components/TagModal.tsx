import { useState } from 'react';
import { X, Hand } from 'lucide-react';
import type { GameSnapshot, Player } from '@/lib/types';
import { taggableTargets } from '@/lib/selectors';

interface Props {
  snapshot: GameSnapshot;
  me: Player;
  onClose: () => void;
  onTag: (targetId: string) => Promise<void>;
}

export function TagModal({ snapshot, me, onClose, onTag }: Props) {
  const targets = taggableTargets(snapshot, me.id);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const tag = async (id: string) => {
    setBusy(id);
    setError(null);
    try {
      await onTag(id);
      onClose();
    } catch (e) {
      const code = (e as any)?.code;
      setError(
        code === 'pending_exists'
          ? 'You already have a tag waiting to be confirmed.'
          : 'Could not send the tag. Try again.',
      );
      setBusy(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/75 p-3 sm:items-center">
      <div className="flex max-h-[85vh] w-full max-w-md animate-slide-down flex-col rounded-3xl border border-ink-700 bg-ink-900">
        <div className="flex items-center justify-between border-b border-ink-700 px-5 py-4">
          <div>
            <h2 className="font-display text-2xl font-black text-white">TAG SOMEONE</h2>
            <p className="text-xs text-ink-500">Pick the safe player you just touched.</p>
          </div>
          <button onClick={onClose} className="rounded-full bg-ink-800 p-2 text-ink-300 active:scale-90">
            <X className="h-5 w-5" />
          </button>
        </div>

        {error && <p className="mx-5 mt-4 rounded-xl bg-it-deep/30 px-3 py-2 text-sm text-it-bright">{error}</p>}

        <div className="grid grid-cols-2 gap-3 overflow-y-auto p-5">
          {targets.length === 0 && (
            <p className="col-span-2 py-8 text-center text-sm text-ink-500">No taggable players right now.</p>
          )}
          {targets.map((p) => (
            <button
              key={p.id}
              onClick={() => tag(p.id)}
              disabled={!!busy}
              className="flex h-20 items-center justify-center gap-2 rounded-2xl border border-ink-700 bg-ink-800 font-display text-lg font-black text-white transition hover:border-safe active:scale-95 disabled:opacity-50"
            >
              {busy === p.id ? 'Sending…' : (
                <>
                  <Hand className="h-4 w-4 text-safe" /> {p.name}
                </>
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
