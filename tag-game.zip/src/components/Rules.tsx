import { ShieldAlert, Footprints, Hand, Users, Eye, School } from 'lucide-react';

const rules = [
  { icon: Footprints, title: 'No dangerous running', desc: 'Walk briskly — never sprint through halls or crowds.' },
  { icon: Hand, title: 'No pushing or shoving', desc: 'A tag is only a light touch on the shoulder or arm.' },
  { icon: Users, title: 'No aggressive contact', desc: 'Never grab, hold, or tackle another player.' },
  { icon: School, title: "Don't interrupt classes", desc: 'Only tag during allowed periods — never during lessons.' },
  { icon: Eye, title: 'Respect personal privacy', desc: 'No tagging or hovering in bathrooms or private areas.' },
  { icon: ShieldAlert, title: 'Follow staff instructions', desc: 'School staff and school rules always override the game.' },
];

export function Rules() {
  return (
    <div className="mx-auto max-w-md space-y-4 px-4 pb-28 pt-5">
      <h1 className="font-display text-4xl font-black text-white">RULES</h1>
      <p className="text-sm text-ink-400">
        TAG! is a friendly game. Play fair, stay safe, and always follow school rules over the game.
      </p>
      <div className="space-y-3">
        {rules.map((r) => (
          <div key={r.title} className="flex items-start gap-3 rounded-2xl border border-ink-700 bg-ink-800 p-4">
            <r.icon className="mt-0.5 h-5 w-5 shrink-0 text-blue-400" />
            <div>
              <p className="font-semibold text-white">{r.title}</p>
              <p className="mt-0.5 text-sm text-ink-400">{r.desc}</p>
            </div>
          </div>
        ))}
      </div>
      <div className="rounded-2xl border border-ink-700 bg-ink-800 p-4 text-sm text-ink-400">
        <p className="font-semibold text-white">Where you can play</p>
        <p className="mt-1">
          Hallways, lunch, and other areas where the school allows the game. The app does not use GPS
          or track your location.
        </p>
      </div>
    </div>
  );
}
