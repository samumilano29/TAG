import { Clock, Zap, Hand, ShieldCheck, Skull, Users, ArrowRight } from 'lucide-react';
import type { GameSnapshot, Player } from '@/lib/types';
import {
  itPlayers,
  isGameLive,
  isPlayerIt,
  lastConfirmedTag,
  playerById,
  activeCount,
  eliminatedCount,
  pendingTagByMe,
} from '@/lib/selectors';
import { formatDuration, secondsUntilEnd, secondsUntilStart, formatClock } from '@/lib/time';

interface Props {
  snapshot: GameSnapshot;
  me: Player;
  serverNow: number;
  onOpenTag: () => void;
}

function elapsed(sinceIso: string, serverNow: number): string {
  return formatDuration((serverNow - new Date(sinceIso).getTime()) / 1000);
}

export function Home({ snapshot, me, serverNow, onOpenTag }: Props) {
  const live = isGameLive(snapshot);
  const tz = snapshot.competition.timezone;
  const its = itPlayers(snapshot);
  const meLatest = playerById(snapshot, me.id) ?? me;
  const iAmIt = isPlayerIt(snapshot, me.id);
  const iAmEliminated = meLatest.status === 'eliminated';
  const last = lastConfirmedTag(snapshot);
  const myPending = pendingTagByMe(snapshot, me.id);

  const secToEnd = secondsUntilEnd(snapshot, serverNow);
  const secToStart = secondsUntilStart(snapshot, serverNow);
  const closingSoon = live && secToEnd <= 600;

  const isFinalDay = snapshot.today?.is_final && snapshot.today.status === 'final_pending';
  const paused = snapshot.competition.status === 'paused';
  const finished = snapshot.competition.status === 'finished';

  return (
    <div className="mx-auto max-w-md space-y-5 px-4 pb-28 pt-5">
      {/* Schedule strip */}
      {finished ? (
        <Banner tone="safe" title="COMPETITION COMPLETE" sub="See the final results in Days." icon={<ShieldCheck className="h-5 w-5" />} />
      ) : isFinalDay ? (
        <Banner tone="pending" title="FINAL DAY" sub="Only two remain. The admin decides the finale." icon={<Zap className="h-5 w-5" />} />
      ) : paused ? (
        <Banner tone="pending" title="GAME PAUSED" sub="Tagging is off until the admin resumes." icon={<Clock className="h-5 w-5" />} />
      ) : live ? (
        <div
          className={`rounded-2xl border p-5 text-center transition ${
            closingSoon ? 'animate-pulse-red border-it bg-it-deep/25' : 'border-ink-700 bg-ink-800'
          }`}
        >
          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-ink-400">Time left today</p>
          <p className={`mt-1 font-display text-5xl font-black tabular-nums ${closingSoon ? 'text-it-bright' : 'text-white'}`}>
            {formatDuration(secToEnd)}
          </p>
          <p className="mt-1 text-xs text-ink-500">Game ends at 2:20 PM</p>
        </div>
      ) : secToStart > 0 ? (
        <div className="rounded-2xl border border-ink-700 bg-ink-800 p-5 text-center">
          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-blue-400">Game starts at 7:20 AM</p>
          <p className="mt-1 font-display text-5xl font-black tabular-nums text-white">{formatDuration(secToStart)}</p>
          <p className="mt-1 text-xs text-ink-500">until tagging goes live</p>
        </div>
      ) : (
        <Banner tone="ink" title="GAME OVER FOR TODAY" sub="Tagging is closed until tomorrow at 7:20 AM." icon={<Clock className="h-5 w-5" />} />
      )}

      {/* My status */}
      {iAmEliminated ? (
        <div className="rounded-2xl border border-ink-600 bg-ink-800 p-5 text-center">
          <Skull className="mx-auto h-8 w-8 text-ink-400" />
          <p className="mt-2 font-display text-2xl font-black text-ink-200">YOU ARE OUT</p>
          <p className="text-sm text-ink-500">Eliminated on Day {meLatest.eliminated_day}. You can still watch the game.</p>
        </div>
      ) : iAmIt ? (
        <div className="animate-pulse-red rounded-2xl border-2 border-it bg-it-deep/25 p-5 text-center">
          <p className="font-display text-4xl font-black text-it-bright">YOU'RE IT</p>
          <p className="mt-1 text-sm text-white/80">Tag a safe player with a light touch, then log it here.</p>
          {live && !myPending && (
            <button
              onClick={onOpenTag}
              className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-it py-3 font-display text-lg font-black text-white active:scale-95"
            >
              <Hand className="h-5 w-5" /> TAG SOMEONE
            </button>
          )}
          {myPending && (
            <p className="mt-4 rounded-xl bg-pending/20 py-2 text-sm font-semibold text-pending-bright">
              Waiting for {playerById(snapshot, myPending.tagged_player_id)?.name} to confirm…
            </p>
          )}
        </div>
      ) : (
        <div className="rounded-2xl border-2 border-safe bg-safe-deep/20 p-5 text-center">
          <ShieldCheck className="mx-auto h-8 w-8 text-safe-bright" />
          <p className="mt-1 font-display text-4xl font-black text-safe-bright">YOU ARE SAFE</p>
          <p className="mt-1 text-sm text-white/70">Stay alert — anyone IT could come for you.</p>
        </div>
      )}

      {/* Currently IT */}
      {its.length > 0 && (
        <div>
          <p className="mb-2 px-1 text-xs font-semibold uppercase tracking-[0.3em] text-ink-400">Currently IT</p>
          {its.map(({ slot, player, since }) => (
            <div key={slot} className="rounded-2xl border border-it/60 bg-it-deep/20 p-5 text-center">
              <span className="inline-block h-2.5 w-2.5 rounded-full bg-it-bright shadow-[0_0_10px_2px_rgba(239,68,68,0.6)]" />
              <p className="mt-2 font-display text-3xl font-black text-white">{player?.name ?? '—'}</p>
              {live && <p className="mt-1 text-xs tabular-nums text-it-bright">IT for {elapsed(since, serverNow)}</p>}
            </div>
          ))}
        </div>
      )}

      {/* Last tag */}
      {last && (
        <div className="flex items-center justify-between rounded-2xl border border-ink-700 bg-ink-800 px-4 py-3">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-ink-500">Last tag</p>
            <p className="mt-0.5 flex items-center gap-2 font-semibold text-white">
              {playerById(snapshot, last.tagger_id)?.name}
              <ArrowRight className="h-4 w-4 text-ink-500" />
              {playerById(snapshot, last.tagged_player_id)?.name}
            </p>
          </div>
          <p className="text-sm text-ink-400">{last.confirmed_at ? formatClock(last.confirmed_at, tz) : ''}</p>
        </div>
      )}

      {/* Roster */}
      <div>
        <div className="mb-2 flex items-center justify-between px-1">
          <p className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-[0.3em] text-ink-400">
            <Users className="h-3.5 w-3.5" /> Roster
          </p>
          <p className="text-xs text-ink-400">
            <span className="text-safe-bright">{activeCount(snapshot)} active</span>
            <span className="mx-1.5 text-ink-600">·</span>
            <span className="text-ink-400">{eliminatedCount(snapshot)} out</span>
          </p>
        </div>
        <div className="grid grid-cols-2 gap-2">
          {[...snapshot.players]
            .sort((a, b) => a.sort_order - b.sort_order)
            .map((p) => {
              const it = isPlayerIt(snapshot, p.id);
              const out = p.status === 'eliminated';
              return (
                <div
                  key={p.id}
                  className={`flex items-center gap-2 rounded-xl border px-3 py-2.5 text-sm font-semibold ${
                    out
                      ? 'border-ink-700 bg-ink-800/40 text-ink-500'
                      : it
                        ? 'border-it/50 bg-it-deep/20 text-white'
                        : 'border-safe/30 bg-safe-deep/10 text-white'
                  }`}
                >
                  <span
                    className={`h-2.5 w-2.5 shrink-0 rounded-full ${
                      out ? 'bg-ink-600' : it ? 'bg-it-bright' : 'bg-safe-bright'
                    }`}
                  />
                  <span className={`truncate ${out ? 'line-through' : ''}`}>{p.name}</span>
                  {p.id === me.id && <span className="ml-auto text-[10px] uppercase text-ink-500">you</span>}
                </div>
              );
            })}
        </div>
      </div>
    </div>
  );
}

function Banner({
  tone,
  title,
  sub,
  icon,
}: {
  tone: 'safe' | 'pending' | 'ink';
  title: string;
  sub: string;
  icon: React.ReactNode;
}) {
  const tones = {
    safe: 'border-safe/50 bg-safe-deep/20 text-safe-bright',
    pending: 'border-pending/50 bg-pending/15 text-pending-bright',
    ink: 'border-ink-700 bg-ink-800 text-ink-200',
  }[tone];
  return (
    <div className={`flex items-center gap-3 rounded-2xl border p-4 ${tones}`}>
      {icon}
      <div>
        <p className="font-display text-xl font-black">{title}</p>
        <p className="text-sm opacity-80">{sub}</p>
      </div>
    </div>
  );
}
