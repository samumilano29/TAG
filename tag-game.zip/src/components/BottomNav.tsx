import { Home, Calendar, Megaphone, ShieldQuestion, Settings as SettingsIcon } from 'lucide-react';

export type Tab = 'home' | 'days' | 'announcements' | 'rules' | 'settings';

interface Props {
  tab: Tab;
  onChange: (t: Tab) => void;
}

const tabs: { id: Tab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'days', label: 'Days', icon: Calendar },
  { id: 'announcements', label: 'News', icon: Megaphone },
  { id: 'rules', label: 'Rules', icon: ShieldQuestion },
  { id: 'settings', label: 'Settings', icon: SettingsIcon },
];

export function BottomNav({ tab, onChange }: Props) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 border-t border-ink-700 bg-ink-900/95 backdrop-blur">
      <div className="mx-auto flex max-w-md items-stretch justify-between px-2 pb-[env(safe-area-inset-bottom)]">
        {tabs.map((t) => {
          const active = tab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => onChange(t.id)}
              className={`flex flex-1 flex-col items-center gap-1 py-2.5 transition ${
                active ? 'text-blue-400' : 'text-ink-500'
              }`}
            >
              <t.icon className="h-5 w-5" />
              <span className="text-[10px] font-semibold uppercase tracking-wide">{t.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
