import { useState } from 'react';
import {
  Lock,
  Play,
  Square,
  Pause,
  PlayCircle,
  RotateCcw,
  Undo2,
  Check,
  X,
  RefreshCw,
  Megaphone,
  Trophy,
  UserCog,
  UserPlus,
  Globe,
} from 'lucide-react';
import type { GameSnapshot, Player } from '@/lib/types';
import { api } from '@/lib/api';
import { playerById, activeCount } from '@/lib/selectors';

interface Props {
  snapshot: GameSnapshot;
  onClose: () => void;
  onDone: () => void;
}

export function Admin({ snapshot, onClose, onDone }: Props) {
  const [pin, setPin] = useState('');
  const [authed, setAuthed] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);

  const run = async (action: string, payload: Record<string, unknown> = {}) => {
    setBusy(action);
    setError(null);
    setMsg(null);
    try {
      await api.admin(action, pin, payload);
      setMsg('Done.');
      onDone();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Action failed');
    } finally {
      setBusy(null);
    }
  };

  if (!authed) {
    return (
      <div className="app-bg flex min-h-screen items-center justify-center px-5">
        <div className="w-full max-w-sm rounded-3xl border border-ink-700 bg-ink-900 p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Lock className="h-5 w-5 text-ink-300" />
              <h2 className="font-display text-2xl font-black text-white">Admin</h2>
            </div>
            <button onClick={onClose} className="rounded-full bg-ink-800 p-2 text-ink-400 active:scale-90">
              <X className="h-5 w-5" />
            </button>
          </div>
          <p className="mt-4 text-sm text-ink-400">Enter the admin pin to manage the game.</p>
          <input
            type="password"
            value={pin}
            onChange={(e) => setPin(e.target.value)}
            placeholder="Pin"
            className="mt-4 w-full rounded-xl border border-ink-600 bg-ink-800 px-4 py-3 text-white outline-none focus:border-blue-500"
          />
          {error && <p className="mt-3 text-sm text-it-bright">{error}</p>}
          <button
            onClick={() => {
              if (!pin) return;
              setBusy('auth');
              api
                .admin('start_day', pin)
                .then(() => {
                  setAuthed(true);
                  setError(null);
                })
                .catch(() => {
                  // A pin check that fails with "already_running" means the pin is valid.
                  setAuthed(true);
                  setError(null);
                })
                .finally(() => setBusy(null));
            }}
            disabled={!pin || !!busy}
            className="mt-4 w-full rounded-xl bg-blue-500 py-3 font-bold text-white active:scale-95 disabled:opacity-50"
          >
            {busy ? 'Checking…' : 'Unlock'}
          </button>
        </div>
      </div>
    );
  }

  const today = snapshot.today;
  const activePlayers = snapshot.players.filter((p) => p.status === 'active');
  const pendingTags = snapshot.recentTags.filter((t) => t.status === 'pending');
  const isFinalPending = today?.is_final && today.status === 'final_pending';

  return (
    <div className="mx-auto max-w-md space-y-5 px-4 pb-28 pt-5">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-4xl font-black text-white">ADMIN</h1>
        <button onClick={onClose} className="rounded-full bg-ink-800 p-2 text-ink-400 active:scale-90">
          <X className="h-5 w-5" />
        </button>
      </div>

      {error && <p className="rounded-xl bg-it-deep/30 px-3 py-2 text-sm text-it-bright">{error}</p>}
      {msg && <p className="rounded-xl bg-safe-deep/20 px-3 py-2 text-sm text-safe-bright">{msg}</p>}

      {/* Day controls */}
      <Section title="Day controls">
        <AdminBtn icon={Play} label="Start day now" loading={busy === 'start_day'} onClick={() => run('start_day')} />
        <AdminBtn icon={Square} label="End day now" loading={busy === 'end_day'} onClick={() => run('end_day')} />
        {snapshot.competition.status === 'paused' ? (
          <AdminBtn icon={PlayCircle} label="Resume tagging" loading={busy === 'resume'} onClick={() => run('resume')} />
        ) : (
          <AdminBtn icon={Pause} label="Pause tagging" loading={busy === 'pause'} onClick={() => run('pause')} />
        )}
      </Section>

      {/* Add player */}
      <Section title="Add a new player">
        <AddPlayerForm onAdd={(name) => run('add_player', { name })} busy={!!busy} />
      </Section>

      {/* Final day */}
      {isFinalPending && (
        <Section title="Final day — pick the winner">
          {activePlayers.map((p) => (
            <AdminBtn
              key={p.id}
              icon={Trophy}
              label={`Declare ${p.name} winner`}
              loading={busy === 'final_winner'}
              onClick={() => run('final_winner', { player_id: p.id })}
            />
          ))}
        </Section>
      )}

      {/* Change IT */}
      {today && today.status === 'running' && (
        <Section title="Change current IT">
          {(() => {
            const current = snapshot.activeTags.find((t) => t.tag_slot === 1);
            const curName = current ? playerById(snapshot, current.current_it_player_id)?.name : '—';
            return (
              <div className="rounded-xl border border-ink-700 bg-ink-800 p-3">
                <p className="mb-2 text-xs font-semibold uppercase text-ink-500">
                  Now IT: <span className="text-white">{curName}</span>
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {activePlayers.map((p) => (
                    <button
                      key={p.id}
                      onClick={() => run('set_it', { slot: 1, player_id: p.id })}
                      disabled={!!busy}
                      className="rounded-lg bg-ink-700 px-2.5 py-1.5 text-xs font-semibold text-white active:scale-95 disabled:opacity-50"
                    >
                      {p.name}
                    </button>
                  ))}
                </div>
              </div>
            );
          })()}
        </Section>
      )}

      {/* Pending tags */}
      {pendingTags.length > 0 && (
        <Section title="Pending tags">
          {pendingTags.map((t) => (
            <div key={t.id} className="rounded-xl border border-pending/40 bg-pending/10 p-3">
              <p className="text-sm text-white">
                <span className="font-bold">{playerById(snapshot, t.tagger_id)?.name}</span> →{' '}
                <span className="font-bold">{playerById(snapshot, t.tagged_player_id)?.name}</span>
                <span className="ml-2 text-xs text-ink-400">slot {t.tag_slot}</span>
              </p>
              <div className="mt-2 flex gap-2">
                <button
                  onClick={() => run('resolve_tag', { tag_id: t.id, approve: true })}
                  disabled={!!busy}
                  className="flex items-center gap-1 rounded-lg bg-safe px-3 py-1.5 text-xs font-bold text-white active:scale-95 disabled:opacity-50"
                >
                  <Check className="h-3.5 w-3.5" /> Approve
                </button>
                <button
                  onClick={() => run('resolve_tag', { tag_id: t.id, approve: false })}
                  disabled={!!busy}
                  className="flex items-center gap-1 rounded-lg bg-it px-3 py-1.5 text-xs font-bold text-white active:scale-95 disabled:opacity-50"
                >
                  <X className="h-3.5 w-3.5" /> Reject
                </button>
              </div>
            </div>
          ))}
        </Section>
      )}

      {/* Recent tags — undo */}
      <Section title="Undo a recent tag">
        {snapshot.recentTags.filter((t) => t.status === 'confirmed').slice(0, 5).map((t) => (
          <AdminBtn
            key={t.id}
            icon={Undo2}
            label={`Undo: ${playerById(snapshot, t.tagger_id)?.name} → ${playerById(snapshot, t.tagged_player_id)?.name}`}
            loading={busy === 'undo_tag'}
            onClick={() => run('undo_tag', { tag_id: t.id })}
          />
        ))}
        {snapshot.recentTags.filter((t) => t.status === 'confirmed').length === 0 && (
          <p className="text-sm text-ink-500">No confirmed tags to undo.</p>
        )}
      </Section>

      {/* Restore player */}
      <Section title="Restore eliminated player">
        {snapshot.players
          .filter((p) => p.status === 'eliminated')
          .map((p) => (
            <AdminBtn
              key={p.id}
              icon={RotateCcw}
              label={`Restore ${p.name}`}
              loading={busy === 'restore_player'}
              onClick={() => run('restore_player', { player_id: p.id })}
            />
          ))}
        {snapshot.players.filter((p) => p.status === 'eliminated').length === 0 && (
          <p className="text-sm text-ink-500">No eliminated players.</p>
        )}
      </Section>

      {/* Rerun elimination */}
      {today && today.status === 'ended' && (
        <Section title="Re-run elimination">
          <AdminBtn
            icon={RefreshCw}
            label="Re-run today's random selection"
            loading={busy === 'rerun_elimination'}
            onClick={() => run('rerun_elimination')}
          />
        </Section>
      )}

      {/* Reset device */}
      <Section title="Reset a player's device">
        {snapshot.players.map((p) => (
          <button
            key={p.id}
            onClick={() => run('reset_device', { player_id: p.id })}
            disabled={!!busy}
            className="flex w-full items-center justify-between rounded-xl border border-ink-700 bg-ink-800 px-3 py-2.5 text-sm active:scale-[0.98] disabled:opacity-50"
          >
            <span className="font-semibold text-white">{p.name}</span>
            <span className="text-xs text-ink-500">
              {p.claimed_device_id ? 'Reset' : 'Free'}
            </span>
          </button>
        ))}
      </Section>

      {/* Custom announcement */}
      <Section title="Custom announcement">
        <AnnounceForm onSend={(title, message) => run('announce', { title, message })} busy={!!busy} />
      </Section>

      {/* Timezone */}
      <Section title="Timezone">
        <TimezoneForm
          current={snapshot.competition.timezone}
          onSave={(tz) => run('set_timezone', { timezone: tz })}
          busy={!!busy}
        />
      </Section>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-ink-700 bg-ink-800 p-4">
      <p className="mb-3 text-xs font-semibold uppercase tracking-wider text-ink-400">{title}</p>
      <div className="space-y-2">{children}</div>
    </div>
  );
}

function AdminBtn({
  icon: Icon,
  label,
  onClick,
  loading,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  onClick: () => void;
  loading?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      disabled={loading}
      className="flex w-full items-center gap-3 rounded-xl border border-ink-700 bg-ink-900 px-3 py-2.5 text-left text-sm font-semibold text-white transition active:scale-[0.98] disabled:opacity-50"
    >
      <Icon className="h-4 w-4 text-blue-400" />
      {loading ? 'Working…' : label}
    </button>
  );
}

function AnnounceForm({ onSend, busy }: { onSend: (title: string, message: string) => void; busy: boolean }) {
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  return (
    <div className="space-y-2">
      <input
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Title"
        className="w-full rounded-lg border border-ink-600 bg-ink-900 px-3 py-2 text-sm text-white outline-none focus:border-blue-500"
      />
      <input
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="Message"
        className="w-full rounded-lg border border-ink-600 bg-ink-900 px-3 py-2 text-sm text-white outline-none focus:border-blue-500"
      />
      <button
        onClick={() => title && onSend(title, message)}
        disabled={busy || !title}
        className="flex w-full items-center justify-center gap-2 rounded-lg bg-blue-500 py-2 text-sm font-bold text-white active:scale-95 disabled:opacity-50"
      >
        <Megaphone className="h-4 w-4" /> Send
      </button>
    </div>
  );
}

function AddPlayerForm({ onAdd, busy }: { onAdd: (name: string) => void; busy: boolean }) {
  const [name, setName] = useState('');
  return (
    <div className="flex gap-2">
      <input
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="Player name"
        className="flex-1 rounded-lg border border-ink-600 bg-ink-900 px-3 py-2 text-sm text-white outline-none focus:border-blue-500"
      />
      <button
        onClick={() => {
          if (name.trim()) {
            onAdd(name.trim());
            setName('');
          }
        }}
        disabled={busy || !name.trim()}
        className="flex items-center gap-1.5 rounded-lg bg-blue-500 px-3 text-sm font-bold text-white active:scale-95 disabled:opacity-50"
      >
        <UserPlus className="h-4 w-4" /> Add
      </button>
    </div>
  );
}

function TimezoneForm({
  current,
  onSave,
  busy,
}: {
  current: string;
  onSave: (tz: string) => void;
  busy: boolean;
}) {
  const [tz, setTz] = useState(current);
  return (
    <div className="flex gap-2">
      <input
        value={tz}
        onChange={(e) => setTz(e.target.value)}
        className="flex-1 rounded-lg border border-ink-600 bg-ink-900 px-3 py-2 text-sm text-white outline-none focus:border-blue-500"
      />
      <button
        onClick={() => onSave(tz)}
        disabled={busy}
        className="flex items-center gap-1.5 rounded-lg bg-ink-700 px-3 text-sm font-semibold text-white active:scale-95 disabled:opacity-50"
      >
        <Globe className="h-4 w-4" /> Save
      </button>
    </div>
  );
}
