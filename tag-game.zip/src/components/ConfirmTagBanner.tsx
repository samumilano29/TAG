import { useState } from 'react';
import { Hand, Check, X } from 'lucide-react';
import type { GameSnapshot, Player, Tag } from '@/lib/types';
import { playerById } from '@/lib/selectors';

interface Props {
  snapshot: GameSnapshot;
  tag: Tag;
  me: Player;
  onConfirm: (tagId: string) => Promise<void>;
  onReject: (tagId: string) => Promise<void>;
}

export function ConfirmTagBanner({ snapshot, tag, onConfirm, onReject }: Props) {
  const tagger = playerById(snapshot, tag.tagger_id);
  const [busy, setBusy] = useState(false);

  const run = async (fn: (id: string) => Promise<void>) => {
    setBusy(true);
    try {
      await fn(tag.id);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-5">
      <div className="w-full max-w-sm animate-scale-in rounded-3xl border-2 border-pending bg-ink-900 p-6 text-center">
        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-pending/20">
          <Hand className="h-8 w-8 text-pending-bright" />
        </div>
        <h2 className="mt-4 font-display text-3xl font-black text-white">YOU GOT TAGGED!</h2>
        <p className="mt-2 text-ink-300">
          <span className="font-bold text-white">{tagger?.name ?? 'Someone'}</span> says they tagged you.
          Confirm if it's true — you'll become IT.
        </p>
        <div className="mt-6 flex gap-3">
          <button
            onClick={() => run(onReject)}
            disabled={busy}
            className="flex flex-1 items-center justify-center gap-2 rounded-xl border border-ink-600 py-3 font-semibold text-ink-200 active:scale-95 disabled:opacity-50"
          >
            <X className="h-4 w-4" /> Not true
          </button>
          <button
            onClick={() => run(onConfirm)}
            disabled={busy}
            className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-it py-3 font-bold text-white active:scale-95 disabled:opacity-50"
          >
            <Check className="h-4 w-4" /> {busy ? 'Confirming…' : "I'm IT now"}
          </button>
        </div>
      </div>
    </div>
  );
}
