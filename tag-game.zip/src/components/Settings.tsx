import { useState } from 'react';
import { RefreshCw, Shield, Lock } from 'lucide-react';
import type { GameSnapshot, Player } from '@/lib/types';
import { clearPlayerId } from '@/lib/device';

interface Props {
  snapshot: GameSnapshot;
  me: Player;
  onSwitchPlayer: () => void;
  onOpenAdmin: () => void;
}

export function Settings({ snapshot, me, onSwitchPlayer, onOpenAdmin }: Props) {
  const [confirmSwitch, setConfirmSwitch] = useState(false);
  const meLatest = snapshot.players.find((p) => p.id === me.id) ?? me;

  return (
    <div className="mx-auto max-w-md space-y-4 px-4 pb-28 pt-5">
      <h1 className="font-display text-4xl font-black text-white">SETTINGS</h1>

      <div className="rounded-2xl border border-ink-700 bg-ink-800 p-5">
        <p className="text-xs font-semibold uppercase tracking-wider text-ink-500">You are playing as</p>
        <p className="mt-1 font-display text-3xl font-black text-white">{meLatest.name}</p>
        <p className="mt-1 text-sm text-ink-400">
          {meLatest.status === 'eliminated'
            ? `Eliminated on Day ${meLatest.eliminated_day}`
            : 'Still in the game'}
        </p>
      </div>

      <button
        onClick={() => setConfirmSwitch(true)}
        className="flex w-full items-center gap-3 rounded-2xl border border-ink-700 bg-ink-800 p-4 text-left transition active:scale-[0.98]"
      >
        <RefreshCw className="h-5 w-5 text-blue-400" />
        <div>
          <p className="font-semibold text-white">Switch player</p>
          <p className="text-sm text-ink-400">Choose a different name on this device.</p>
        </div>
      </button>

      <button
        onClick={onOpenAdmin}
        className="flex w-full items-center gap-3 rounded-2xl border border-ink-700 bg-ink-800 p-4 text-left transition active:scale-[0.98]"
      >
        <Lock className="h-5 w-5 text-ink-300" />
        <div>
          <p className="font-semibold text-white">Admin controls</p>
          <p className="text-sm text-ink-400">Manage the game with a pin.</p>
        </div>
      </button>

      {confirmSwitch && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 p-4 sm:items-center">
          <div className="w-full max-w-sm animate-slide-down rounded-3xl border border-ink-700 bg-ink-900 p-6 text-center">
            <Shield className="mx-auto h-10 w-10 text-blue-400" />
            <h2 className="mt-3 font-display text-2xl font-black text-white">Switch player?</h2>
            <p className="mt-2 text-sm text-ink-400">
              You'll need to pick your name again. Your game history stays saved.
            </p>
            <div className="mt-6 flex gap-3">
              <button
                onClick={() => setConfirmSwitch(false)}
                className="flex-1 rounded-xl border border-ink-600 py-3 font-semibold text-ink-200 active:scale-95"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  clearPlayerId();
                  onSwitchPlayer();
                }}
                className="flex-1 rounded-xl bg-blue-500 py-3 font-bold text-white active:scale-95"
              >
                Switch
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
