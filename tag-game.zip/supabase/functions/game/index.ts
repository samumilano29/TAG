import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

// ---- time helpers (server-authoritative, timezone aware) ----

function tzParts(date: Date, tz: string) {
  const dtf = new Intl.DateTimeFormat("en-US", {
    timeZone: tz,
    hour12: false,
    weekday: "short",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
  const map: Record<string, string> = {};
  for (const p of dtf.formatToParts(date)) map[p.type] = p.value;
  return {
    year: +map.year,
    month: +map.month,
    day: +map.day,
    hour: +map.hour === 24 ? 0 : +map.hour,
    minute: +map.minute,
    second: +map.second,
    weekday: map.weekday, // Mon, Tue...
    dateStr: `${map.year}-${map.month}-${map.day}`,
  };
}

function parseHM(hm: string) {
  const [h, m] = hm.split(":").map((n) => parseInt(n, 10));
  return h * 60 + m;
}

function isWeekday(weekday: string) {
  return !["Sat", "Sun"].includes(weekday);
}

function pickRandom<T>(arr: T[], count: number): T[] {
  const copy = [...arr];
  const out: T[] = [];
  for (let i = 0; i < count && copy.length; i++) {
    const idx = Math.floor(Math.random() * copy.length);
    out.push(copy.splice(idx, 1)[0]);
  }
  return out;
}

async function announce(
  competitionId: string,
  dailyGameId: string | null,
  type: string,
  title: string,
  message: string,
) {
  await supabase.from("announcements").insert({
    competition_id: competitionId,
    daily_game_id: dailyGameId,
    type,
    title,
    message,
  });
}

async function loadState() {
  const { data: competition } = await supabase.from("competition").select("*").limit(1).maybeSingle();
  const { data: players } = await supabase.from("players").select("*").order("sort_order");
  return { competition, players: players ?? [] };
}

// Auto start / end a day based on server time. Returns nothing; mutates DB.
async function runSchedule() {
  const { competition, players } = await loadState();
  if (!competition) return;
  if (competition.status === "finished") return;

  const now = new Date();
  const tz = competition.timezone;
  const local = tzParts(now, tz);
  const curMin = local.hour * 60 + local.minute;
  const startMin = parseHM(competition.start_time);
  const endMin = parseHM(competition.end_time);
  const activePlayers = players.filter((p) => p.status === "active");

  // Find the most recent daily game
  const { data: latest } = await supabase
    .from("daily_games")
    .select("*")
    .eq("competition_id", competition.id)
    .order("day_number", { ascending: false })
    .limit(1)
    .maybeSingle();

  // 1. End a running game whose window has passed.
  if (latest && latest.status === "running") {
    const passed = latest.date < local.dateStr || (latest.date === local.dateStr && curMin >= endMin);
    if (passed) {
      await endDay(competition, latest);
      return; // re-evaluate on next tick
    }
  }

  if (competition.status === "paused") return;

  // 2. Auto-start today's game if in window and none exists yet for today.
  const windowActive = isWeekday(local.weekday) && curMin >= startMin && curMin < endMin;
  const hasTodayGame = latest && latest.date === local.dateStr;

  if (windowActive && !hasTodayGame) {
    if (activePlayers.length <= 1) {
      // Competition already decided.
      if (activePlayers.length === 1 && competition.status !== "finished") {
        await supabase.from("competition").update({ status: "finished" }).eq("id", competition.id);
        await announce(competition.id, null, "winner", "WE HAVE A WINNER",
          `${activePlayers[0].name} is the last player standing and wins TAG!`);
      }
      return;
    }

    const dayNumber = (latest?.day_number ?? 0) + 1;
    const isFinal = activePlayers.length === 2;

    const { data: game } = await supabase
      .from("daily_games")
      .insert({
        competition_id: competition.id,
        day_number: dayNumber,
        date: local.dateStr,
        status: isFinal ? "final_pending" : "running",
        is_final: isFinal,
        started_at: now.toISOString(),
      })
      .select()
      .maybeSingle();

    await supabase.from("competition").update({ current_day: dayNumber }).eq("id", competition.id);

    if (!game) return;

    if (isFinal) {
      await announce(competition.id, game.id, "final_day", "FINAL DAY",
        `Only ${activePlayers[0].name} and ${activePlayers[1].name} remain. The admin will set the final rules.`);
    } else {
      const [a] = pickRandom(activePlayers, 1);
      await supabase.from("active_tags").insert([
        { daily_game_id: game.id, current_it_player_id: a.id, tag_slot: 1, started_at: now.toISOString() },
      ]);
      await supabase.from("daily_games").update({ starting_it_ids: [a.id] }).eq("id", game.id);
      await announce(competition.id, game.id, "day_start", `DAY ${dayNumber}`,
        `${a.name} is IT! The game is live.`);
    }
  }
}

async function endDay(competition: any, game: any) {
  const now = new Date();
  // Current IT player.
  const { data: slots } = await supabase
    .from("active_tags")
    .select("*")
    .eq("daily_game_id", game.id)
    .order("tag_slot");

  let eliminatedId: string | null = null;
  if (slots && slots.length > 0) {
    eliminatedId = slots[0].current_it_player_id;
  }

  const finalItIds = slots?.map((s) => s.current_it_player_id) ?? [];
  await supabase
    .from("daily_games")
    .update({ status: "ended", ended_at: now.toISOString(), eliminated_player_id: eliminatedId, final_it_ids: finalItIds })
    .eq("id", game.id);

  if (eliminatedId) {
    await supabase
      .from("players")
      .update({ status: "eliminated", eliminated_day: game.day_number, eliminated_at: now.toISOString() })
      .eq("id", eliminatedId);
  }

  // Names for announcement.
  const { data: players } = await supabase.from("players").select("*");
  const nameOf = (id: string | null) => players?.find((p) => p.id === id)?.name ?? "Unknown";
  const itName = slots?.map((s) => nameOf(s.current_it_player_id)).join(", ") ?? "Unknown";
  const remaining = (players ?? []).filter((p) => p.status === "active").length;

  await announce(
    competition.id,
    game.id,
    "day_result",
    `DAY ${game.day_number} RESULTS`,
    `${itName} was IT at the end and has been eliminated. ${remaining} players remaining.`,
  );

  // If exactly one active player remains, the competition is over.
  if (remaining === 1) {
    const winner = (players ?? []).find((p) => p.status === "active");
    await supabase.from("competition").update({ status: "finished" }).eq("id", competition.id);
    await announce(competition.id, game.id, "winner", "WE HAVE A WINNER",
      `${winner?.name ?? "Unknown"} is the last player standing and wins TAG!`);
  }
}

async function getSnapshot() {
  const { competition, players } = await loadState();
  if (!competition) return { error: "no_competition" };

  const now = new Date();
  const tz = competition.timezone;
  const local = tzParts(now, tz);
  const curMin = local.hour * 60 + local.minute;
  const startMin = parseHM(competition.start_time);
  const endMin = parseHM(competition.end_time);
  const windowActive = isWeekday(local.weekday) && curMin >= startMin && curMin < endMin && competition.status === "active";

  const { data: latest } = await supabase
    .from("daily_games")
    .select("*")
    .eq("competition_id", competition.id)
    .order("day_number", { ascending: false })
    .limit(1)
    .maybeSingle();

  let activeTags: any[] = [];
  let recentTags: any[] = [];
  if (latest) {
    const { data: at } = await supabase.from("active_tags").select("*").eq("daily_game_id", latest.id).order("tag_slot");
    activeTags = at ?? [];
    const { data: rt } = await supabase
      .from("tags")
      .select("*")
      .eq("daily_game_id", latest.id)
      .order("created_at", { ascending: false })
      .limit(20);
    recentTags = rt ?? [];
  }

  const { data: allGames } = await supabase
    .from("daily_games")
    .select("*")
    .eq("competition_id", competition.id)
    .order("day_number", { ascending: false });

  const { data: announcements } = await supabase
    .from("announcements")
    .select("*")
    .eq("competition_id", competition.id)
    .order("created_at", { ascending: false })
    .limit(50);

  return {
    serverTime: now.getTime(),
    competition,
    players,
    today: latest,
    activeTags,
    recentTags,
    allGames: allGames ?? [],
    announcements: announcements ?? [],
    schedule: { startMin, endMin, curMin, localDate: local.dateStr, weekday: local.weekday, windowActive },
  };
}

function gameIsLive(snap: any): boolean {
  return (
    snap.competition.status === "active" &&
    snap.today &&
    snap.today.status === "running" &&
    snap.schedule.windowActive
  );
}

// ---- action handlers ----

async function handleClaim(body: any) {
  const { player_id, device_id } = body;
  const { data: player } = await supabase.from("players").select("*").eq("id", player_id).maybeSingle();
  if (!player) return json({ error: "player_not_found" }, 404);
  if (player.claimed_device_id && player.claimed_device_id !== device_id) {
    return json({ error: "already_claimed", conflict: true }, 409);
  }
  await supabase.from("players").update({ claimed_device_id: device_id }).eq("id", player_id);
  return json({ ok: true });
}

async function handleTag(body: any) {
  const { tagger_id, tagged_player_id } = body;
  const snap = await getSnapshot();
  if ("error" in snap) return json(snap, 400);
  if (!gameIsLive(snap)) return json({ error: "game_not_live" }, 400);

  const slot = snap.activeTags.find((t: any) => t.current_it_player_id === tagger_id);
  if (!slot) return json({ error: "not_it" }, 403);

  const target = snap.players.find((p: any) => p.id === tagged_player_id);
  if (!target || target.status !== "active") return json({ error: "invalid_target" }, 400);

  // One pending tag per slot at a time.
  const existingPending = snap.recentTags.find((t: any) => t.tag_slot === slot.tag_slot && t.status === "pending");
  if (existingPending) return json({ error: "pending_exists" }, 409);

  const { data: tag } = await supabase
    .from("tags")
    .insert({
      daily_game_id: snap.today.id,
      tag_slot: slot.tag_slot,
      tagger_id,
      tagged_player_id,
      status: "pending",
    })
    .select()
    .maybeSingle();

  return json({ ok: true, tag });
}

async function handleConfirmTag(body: any) {
  const { tag_id, player_id } = body;
  const { data: tag } = await supabase.from("tags").select("*").eq("id", tag_id).maybeSingle();
  if (!tag || tag.status !== "pending") return json({ error: "tag_not_pending" }, 400);
  if (tag.tagged_player_id !== player_id) return json({ error: "not_your_tag" }, 403);

  const now = new Date().toISOString();
  await supabase.from("tags").update({ status: "confirmed", confirmed_at: now }).eq("id", tag_id);
  await supabase
    .from("active_tags")
    .update({ current_it_player_id: tag.tagged_player_id, started_at: now })
    .eq("daily_game_id", tag.daily_game_id)
    .eq("tag_slot", tag.tag_slot);

  return json({ ok: true });
}

async function handleRejectTag(body: any) {
  const { tag_id, player_id } = body;
  const { data: tag } = await supabase.from("tags").select("*").eq("id", tag_id).maybeSingle();
  if (!tag || tag.status !== "pending") return json({ error: "tag_not_pending" }, 400);
  if (tag.tagged_player_id !== player_id) return json({ error: "not_your_tag" }, 403);
  await supabase.from("tags").update({ status: "rejected" }).eq("id", tag_id);
  return json({ ok: true });
}

async function requireAdmin(body: any) {
  const { data: competition } = await supabase.from("competition").select("*").limit(1).maybeSingle();
  if (!competition) return null;
  if (body.pin !== competition.admin_pin) return null;
  return competition;
}

async function handleAdmin(action: string, body: any) {
  const competition = await requireAdmin(body);
  if (!competition) return json({ error: "unauthorized" }, 401);

  const { data: players } = await supabase.from("players").select("*").order("sort_order");
  const nameOf = (id: string | null) => players?.find((p) => p.id === id)?.name ?? "Unknown";
  const now = new Date();
  const tz = competition.timezone;
  const local = tzParts(now, tz);

  const latest = (
    await supabase.from("daily_games").select("*").eq("competition_id", competition.id)
      .order("day_number", { ascending: false }).limit(1).maybeSingle()
  ).data;

  switch (action) {
    case "start_day": {
      if (latest && latest.date === local.dateStr && latest.status === "running") {
        return json({ error: "already_running" }, 400);
      }
      const activePlayers = (players ?? []).filter((p) => p.status === "active");
      if (activePlayers.length < 2) return json({ error: "not_enough_players" }, 400);
      const dayNumber = (latest?.day_number ?? 0) + 1;
      const isFinal = activePlayers.length === 2;
      const { data: game } = await supabase.from("daily_games").insert({
        competition_id: competition.id,
        day_number: dayNumber,
        date: local.dateStr,
        status: isFinal ? "final_pending" : "running",
        is_final: isFinal,
        started_at: now.toISOString(),
      }).select().maybeSingle();
      await supabase.from("competition").update({ current_day: dayNumber, status: "active" }).eq("id", competition.id);
      if (game && !isFinal) {
        const [a] = pickRandom(activePlayers, 1);
        await supabase.from("active_tags").insert([
          { daily_game_id: game.id, current_it_player_id: a.id, tag_slot: 1 },
        ]);
        await supabase.from("daily_games").update({ starting_it_ids: [a.id] }).eq("id", game.id);
        await announce(competition.id, game.id, "day_start", `DAY ${dayNumber}`, `${a.name} is IT!`);
      } else if (game && isFinal) {
        await announce(competition.id, game.id, "final_day", "FINAL DAY", "The final two remain. Admin sets the rules.");
      }
      return json({ ok: true });
    }
    case "end_day": {
      if (!latest || latest.status !== "running") return json({ error: "no_running_game" }, 400);
      await endDay(competition, latest);
      return json({ ok: true });
    }
    case "pause": {
      await supabase.from("competition").update({ status: "paused" }).eq("id", competition.id);
      await announce(competition.id, latest?.id ?? null, "info", "GAME PAUSED", "Tagging is temporarily paused by the admin.");
      return json({ ok: true });
    }
    case "resume": {
      await supabase.from("competition").update({ status: "active" }).eq("id", competition.id);
      await announce(competition.id, latest?.id ?? null, "info", "GAME RESUMED", "Tagging is back on.");
      return json({ ok: true });
    }
    case "set_it": {
      const { slot, player_id } = body;
      if (!latest) return json({ error: "no_game" }, 400);
      const existing = (await supabase.from("active_tags").select("*").eq("daily_game_id", latest.id).eq("tag_slot", slot).maybeSingle()).data;
      if (existing) {
        await supabase.from("active_tags").update({ current_it_player_id: player_id, started_at: now.toISOString() }).eq("id", existing.id);
      } else {
        await supabase.from("active_tags").insert({ daily_game_id: latest.id, current_it_player_id: player_id, tag_slot: slot });
      }
      await announce(competition.id, latest.id, "info", "IT CHANGED", `${nameOf(player_id)} is now IT (slot ${slot}).`);
      return json({ ok: true });
    }
    case "undo_tag": {
      const { tag_id } = body;
      const tag = (await supabase.from("tags").select("*").eq("id", tag_id).maybeSingle()).data;
      if (!tag) return json({ error: "not_found" }, 404);
      await supabase.from("tags").update({ status: "undone" }).eq("id", tag_id);
      // Restore the tagger to IT in that slot.
      await supabase.from("active_tags").update({ current_it_player_id: tag.tagger_id, started_at: now.toISOString() })
        .eq("daily_game_id", tag.daily_game_id).eq("tag_slot", tag.tag_slot);
      await announce(competition.id, tag.daily_game_id, "info", "TAG UNDONE", `A tag was undone by the admin. ${nameOf(tag.tagger_id)} is IT again.`);
      return json({ ok: true });
    }
    case "resolve_tag": {
      const { tag_id, approve } = body;
      const tag = (await supabase.from("tags").select("*").eq("id", tag_id).maybeSingle()).data;
      if (!tag || tag.status !== "pending") return json({ error: "not_pending" }, 400);
      if (approve) {
        const iso = now.toISOString();
        await supabase.from("tags").update({ status: "confirmed", confirmed_at: iso }).eq("id", tag_id);
        await supabase.from("active_tags").update({ current_it_player_id: tag.tagged_player_id, started_at: iso })
          .eq("daily_game_id", tag.daily_game_id).eq("tag_slot", tag.tag_slot);
      } else {
        await supabase.from("tags").update({ status: "rejected" }).eq("id", tag_id);
      }
      return json({ ok: true });
    }
    case "restore_player": {
      const { player_id } = body;
      await supabase.from("players").update({ status: "active", eliminated_day: null, eliminated_at: null }).eq("id", player_id);
      // If this player was recorded as a day's eliminated player, clear it.
      await supabase.from("daily_games").update({ eliminated_player_id: null }).eq("eliminated_player_id", player_id);
      await supabase.from("competition").update({ status: "active" }).eq("id", competition.id);
      await announce(competition.id, latest?.id ?? null, "info", "PLAYER RESTORED", `${nameOf(player_id)} has been restored to the game.`);
      return json({ ok: true });
    }
    case "rerun_elimination": {
      if (!latest || latest.status !== "ended") return json({ error: "no_ended_game" }, 400);
      // Restore previously eliminated player from this day, then re-run.
      if (latest.eliminated_player_id) {
        await supabase.from("players").update({ status: "active", eliminated_day: null, eliminated_at: null })
          .eq("id", latest.eliminated_player_id);
      }
      const slots = (await supabase.from("active_tags").select("*").eq("daily_game_id", latest.id)).data ?? [];
      const itIds = slots.map((s) => s.current_it_player_id);
      const chosen = itIds.length ? itIds[Math.floor(Math.random() * itIds.length)] : null;
      await supabase.from("daily_games").update({ eliminated_player_id: chosen }).eq("id", latest.id);
      if (chosen) {
        await supabase.from("players").update({ status: "eliminated", eliminated_day: latest.day_number, eliminated_at: now.toISOString() }).eq("id", chosen);
      }
      await announce(competition.id, latest.id, "day_result", `DAY ${latest.day_number} RE-RUN`, `${nameOf(chosen)} has been eliminated.`);
      return json({ ok: true });
    }
    case "announce": {
      await announce(competition.id, latest?.id ?? null, "custom", body.title ?? "ANNOUNCEMENT", body.message ?? "");
      return json({ ok: true });
    }
    case "reset_device": {
      const { player_id } = body;
      await supabase.from("players").update({ claimed_device_id: null }).eq("id", player_id);
      return json({ ok: true });
    }
    case "final_winner": {
      const { player_id } = body;
      if (!latest) return json({ error: "no_game" }, 400);
      const activePlayers = (players ?? []).filter((p) => p.status === "active");
      const loser = activePlayers.find((p) => p.id !== player_id);
      if (loser) {
        await supabase.from("players").update({ status: "eliminated", eliminated_day: latest.day_number, eliminated_at: now.toISOString() }).eq("id", loser.id);
      }
      await supabase.from("daily_games").update({ status: "final_done", ended_at: now.toISOString(), eliminated_player_id: loser?.id ?? null }).eq("id", latest.id);
      await supabase.from("competition").update({ status: "finished" }).eq("id", competition.id);
      await announce(competition.id, latest.id, "winner", "WE HAVE A WINNER", `${nameOf(player_id)} wins TAG! ${loser ? nameOf(loser.id) + " finishes second." : ""}`);
      return json({ ok: true });
    }
    case "set_timezone": {
      await supabase.from("competition").update({ timezone: body.timezone }).eq("id", competition.id);
      return json({ ok: true });
    }
    case "add_player": {
      const name = (body.name ?? "").toString().trim();
      if (!name) return json({ error: "name_required" }, 400);
      const { error: insertError } = await supabase.from("players").insert({
        name,
        sort_order: (players?.length ?? 0) + 1,
      });
      if (insertError) return json({ error: "name_exists" }, 409);
      await announce(competition.id, latest?.id ?? null, "info", "NEW PLAYER", `${name} joined the game.`);
      return json({ ok: true });
    }
    default:
      return json({ error: "unknown_admin_action" }, 400);
  }
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }
  try {
    const body = req.method === "POST" ? await req.json().catch(() => ({})) : {};
    const action = body.action ?? "state";

    // Every request advances the server-authoritative schedule first.
    if (["state", "tag", "confirm_tag", "reject_tag"].includes(action)) {
      await runSchedule();
    }

    switch (action) {
      case "state": {
        const snap = await getSnapshot();
        if ("error" in snap) return json(snap, 400);
        return json(snap);
      }
      case "claim":
        return await handleClaim(body);
      case "tag":
        return await handleTag(body);
      case "confirm_tag":
        return await handleConfirmTag(body);
      case "reject_tag":
        return await handleRejectTag(body);
      default:
        if (action.startsWith("admin_")) {
          return await handleAdmin(action.replace("admin_", ""), body);
        }
        return json({ error: "unknown_action" }, 400);
    }
  } catch (err) {
    return json({ error: String(err instanceof Error ? err.message : err) }, 500);
  }
});
